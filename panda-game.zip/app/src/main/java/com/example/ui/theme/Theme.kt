package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

enum class ThemeMode {
    SYSTEM,
    LIGHT,
    DARK
}

private val MusicDarkColorScheme = darkColorScheme(
    primary = MusicPrimary,
    onPrimary = Color.White,
    primaryContainer = MusicDarkSurfaceVariant,
    onPrimaryContainer = MusicAccent,
    secondary = MusicSecondary,
    onSecondary = Color.Black,
    secondaryContainer = Color(0xFF164E63),
    onSecondaryContainer = Color(0xFFCFFAFE),
    tertiary = MusicTertiary,
    onTertiary = Color.White,
    background = MusicDarkBackground,
    onBackground = MusicTextPrimaryDark,
    surface = MusicDarkSurface,
    onSurface = MusicTextPrimaryDark,
    surfaceVariant = MusicDarkSurfaceVariant,
    onSurfaceVariant = MusicTextSecondaryDark,
    outline = MusicDarkBorder,
    outlineVariant = Color(0xFF2D2A40)
)

private val MusicLightColorScheme = lightColorScheme(
    primary = MusicPrimaryVariant,
    onPrimary = Color.White,
    primaryContainer = MusicLightSurfaceVariant,
    onPrimaryContainer = MusicPrimaryVariant,
    secondary = MusicSecondary,
    onSecondary = Color.White,
    secondaryContainer = Color(0xFFE0F2FE),
    onSecondaryContainer = Color(0xFF0369A1),
    tertiary = MusicTertiary,
    onTertiary = Color.White,
    background = MusicLightBackground,
    onBackground = MusicTextPrimaryLight,
    surface = MusicLightSurface,
    onSurface = MusicTextPrimaryLight,
    surfaceVariant = MusicLightSurfaceVariant,
    onSurfaceVariant = MusicTextSecondaryLight,
    outline = MusicLightBorder,
    outlineVariant = Color(0xFFE2E8F0)
)

@Composable
fun MusicPlayerTheme(
    themeMode: ThemeMode = ThemeMode.SYSTEM,
    content: @Composable () -> Unit
) {
    val darkTheme = when (themeMode) {
        ThemeMode.SYSTEM -> isSystemInDarkTheme()
        ThemeMode.DARK -> true
        ThemeMode.LIGHT -> false
    }

    val colorScheme = if (darkTheme) MusicDarkColorScheme else MusicLightColorScheme

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
