package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Premium Music Player Color Palette
// Deep Twilight Dark Canvas
val MusicDarkBackground = Color(0xFF0F0E17)
val MusicDarkSurface = Color(0xFF1B1926)
val MusicDarkSurfaceVariant = Color(0xFF272438)
val MusicDarkCard = Color(0xFF221F33)
val MusicDarkBorder = Color(0xFF37334F)

// Light Canvas
val MusicLightBackground = Color(0xFFF7F7FC)
val MusicLightSurface = Color(0xFFFFFFFF)
val MusicLightSurfaceVariant = Color(0xFFEEEAF8)
val MusicLightCard = Color(0xFFFFFFFF)
val MusicLightBorder = Color(0xFFE2DDF0)

// Vibrant Accent Colors
val MusicPrimary = Color(0xFF8B5CF6)       // Vibrant Electric Violet
val MusicPrimaryVariant = Color(0xFF7C3AED)
val MusicSecondary = Color(0xFF06B6D4)     // Cyan Glow
val MusicTertiary = Color(0xFFEC4899)      // Neon Rose
val MusicAccent = Color(0xFFA78BFA)

// Functional colors
val MusicPlayingGlow = Color(0xFF10B981)   // Emerald Green for active status
val MusicFavoriteRed = Color(0xFFEF4444)   // Heart red
val MusicTextPrimaryDark = Color(0xFFF9FAFB)
val MusicTextSecondaryDark = Color(0xFF9CA3AF)
val MusicTextPrimaryLight = Color(0xFF111827)
val MusicTextSecondaryLight = Color(0xFF4B5563)
