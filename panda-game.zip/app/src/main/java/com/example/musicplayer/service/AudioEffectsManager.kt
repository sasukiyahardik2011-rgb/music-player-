package com.example.musicplayer.service

import android.media.audiofx.BassBoost
import android.media.audiofx.Equalizer
import android.media.audiofx.Virtualizer
import android.util.Log
import com.example.musicplayer.model.EqualizerState
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

class AudioEffectsManager {

    private val _equalizerState = MutableStateFlow(EqualizerState())
    val equalizerState: StateFlow<EqualizerState> = _equalizerState.asStateFlow()

    private var equalizer: Equalizer? = null
    private var bassBoost: BassBoost? = null
    private var virtualizer: Virtualizer? = null
    private var currentSessionId: Int = 0

    fun attachAudioSession(audioSessionId: Int) {
        if (audioSessionId == 0 || audioSessionId == currentSessionId) return
        currentSessionId = audioSessionId
        releaseEffects()

        try {
            val eq = Equalizer(0, audioSessionId)
            equalizer = eq

            val presets = mutableListOf<String>()
            val numPresets = eq.numberOfPresets.toInt()
            for (i in 0 until numPresets) {
                try {
                    presets.add(eq.getPresetName(i.toShort()))
                } catch (e: Exception) {
                    presets.add("Preset $i")
                }
            }
            if (presets.isEmpty()) {
                presets.addAll(listOf("Normal", "Classical", "Dance", "Flat", "Folk", "Heavy Metal", "Hip Hop", "Jazz", "Pop", "Rock"))
            }

            val bandLevels = mutableMapOf<Short, Short>()
            val bandCenterFreqs = mutableMapOf<Short, Int>()
            val numBands = eq.numberOfBands

            for (b in 0 until numBands.toInt()) {
                val band = b.toShort()
                bandLevels[band] = eq.getBandLevel(band)
                bandCenterFreqs[band] = eq.getCenterFreq(band)
            }

            val bandRange = eq.bandLevelRange
            val minBand = bandRange?.getOrNull(0) ?: -1500
            val maxBand = bandRange?.getOrNull(1) ?: 1500

            // Bass boost
            var bbStrength: Short = 0
            try {
                val bb = BassBoost(0, audioSessionId)
                if (bb.strengthSupported) {
                    bassBoost = bb
                    bbStrength = bb.roundedStrength
                }
            } catch (e: Exception) {
                Log.w(TAG, "BassBoost unsupported: ${e.message}")
            }

            // Virtualizer
            var virtStrength: Short = 0
            try {
                val virt = Virtualizer(0, audioSessionId)
                if (virt.strengthSupported) {
                    virtualizer = virt
                    virtStrength = virt.roundedStrength
                }
            } catch (e: Exception) {
                Log.w(TAG, "Virtualizer unsupported: ${e.message}")
            }

            _equalizerState.value = EqualizerState(
                isSupported = true,
                isEnabled = eq.enabled,
                currentPreset = eq.currentPreset.toInt().coerceAtLeast(0),
                presets = presets,
                bandLevels = bandLevels,
                minBandLevel = minBand,
                maxBandLevel = maxBand,
                bandCenterFreqs = bandCenterFreqs,
                bassBoostStrength = bbStrength,
                virtualizerStrength = virtStrength
            )
        } catch (e: Exception) {
            Log.w(TAG, "Equalizer initialization failed: ${e.message}")
            _equalizerState.value = EqualizerState(
                isSupported = false,
                isEnabled = false,
                presets = listOf("Normal", "Classical", "Dance", "Flat", "Folk", "Heavy Metal", "Hip Hop", "Jazz", "Pop", "Rock")
            )
        }
    }

    fun setEnabled(enabled: Boolean) {
        try {
            equalizer?.enabled = enabled
            bassBoost?.enabled = enabled
            virtualizer?.enabled = enabled
            _equalizerState.value = _equalizerState.value.copy(isEnabled = enabled)
        } catch (e: Exception) {
            Log.w(TAG, "Failed to toggle equalizer: ${e.message}")
        }
    }

    fun usePreset(presetIndex: Int) {
        try {
            val eq = equalizer ?: return
            if (presetIndex in 0 until eq.numberOfPresets.toInt()) {
                eq.usePreset(presetIndex.toShort())
                val updatedBands = mutableMapOf<Short, Short>()
                for (b in 0 until eq.numberOfBands.toInt()) {
                    val band = b.toShort()
                    updatedBands[band] = eq.getBandLevel(band)
                }
                _equalizerState.value = _equalizerState.value.copy(
                    currentPreset = presetIndex,
                    bandLevels = updatedBands
                )
            }
        } catch (e: Exception) {
            Log.w(TAG, "Failed to set preset: ${e.message}")
        }
    }

    fun setBandLevel(band: Short, level: Short) {
        try {
            equalizer?.setBandLevel(band, level)
            val updated = _equalizerState.value.bandLevels.toMutableMap()
            updated[band] = level
            _equalizerState.value = _equalizerState.value.copy(bandLevels = updated)
        } catch (e: Exception) {
            Log.w(TAG, "Failed to set band level: ${e.message}")
        }
    }

    fun setBassBoost(strength: Short) {
        try {
            bassBoost?.setStrength(strength)
            _equalizerState.value = _equalizerState.value.copy(bassBoostStrength = strength)
        } catch (e: Exception) {
            Log.w(TAG, "Failed to set bass boost: ${e.message}")
        }
    }

    fun setVirtualizer(strength: Short) {
        try {
            virtualizer?.setStrength(strength)
            _equalizerState.value = _equalizerState.value.copy(virtualizerStrength = strength)
        } catch (e: Exception) {
            Log.w(TAG, "Failed to set virtualizer: ${e.message}")
        }
    }

    fun releaseEffects() {
        try {
            equalizer?.release()
            equalizer = null
            bassBoost?.release()
            bassBoost = null
            virtualizer?.release()
            virtualizer = null
        } catch (e: Exception) {
            Log.w(TAG, "Error releasing audio effects: ${e.message}")
        }
    }

    companion object {
        private const val TAG = "AudioEffectsManager"
    }
}
