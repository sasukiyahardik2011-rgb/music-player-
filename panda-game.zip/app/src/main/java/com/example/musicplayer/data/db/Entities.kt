package com.example.musicplayer.data.db

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey
import com.example.musicplayer.model.Song

@Entity(tableName = "favorites")
data class FavoriteSongEntity(
    @PrimaryKey
    val songId: Long,
    val title: String,
    val artist: String,
    val album: String,
    val albumId: Long = 0L,
    val duration: Long,
    val uri: String,
    val albumArtUri: String? = null,
    val path: String = "",
    val folder: String = "Music",
    val addedAt: Long = System.currentTimeMillis()
) {
    fun toSong(): Song = Song(
        id = songId,
        title = title,
        artist = artist,
        album = album,
        albumId = albumId,
        duration = duration,
        uri = uri,
        albumArtUri = albumArtUri,
        path = path,
        folder = folder,
        dateAdded = addedAt
    )
}

@Entity(
    tableName = "recently_played",
    indices = [Index(value = ["songId"])]
)
data class RecentlyPlayedEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0L,
    val songId: Long,
    val title: String,
    val artist: String,
    val album: String,
    val albumId: Long = 0L,
    val duration: Long,
    val uri: String,
    val albumArtUri: String? = null,
    val path: String = "",
    val folder: String = "Music",
    val playedAt: Long = System.currentTimeMillis()
) {
    fun toSong(): Song = Song(
        id = songId,
        title = title,
        artist = artist,
        album = album,
        albumId = albumId,
        duration = duration,
        uri = uri,
        albumArtUri = albumArtUri,
        path = path,
        folder = folder,
        dateAdded = playedAt
    )
}

@Entity(tableName = "playlists")
data class PlaylistEntity(
    @PrimaryKey(autoGenerate = true)
    val playlistId: Long = 0L,
    val name: String,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(
    tableName = "playlist_songs",
    indices = [Index(value = ["playlistId", "songId"])]
)
data class PlaylistSongCrossRef(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0L,
    val playlistId: Long,
    val songId: Long,
    val sortOrder: Int = 0,
    val title: String,
    val artist: String,
    val album: String,
    val albumId: Long = 0L,
    val duration: Long,
    val uri: String,
    val albumArtUri: String? = null,
    val path: String = "",
    val folder: String = "Music"
) {
    fun toSong(): Song = Song(
        id = songId,
        title = title,
        artist = artist,
        album = album,
        albumId = albumId,
        duration = duration,
        uri = uri,
        albumArtUri = albumArtUri,
        path = path,
        folder = folder
    )
}
