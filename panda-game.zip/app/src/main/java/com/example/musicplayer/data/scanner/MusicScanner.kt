package com.example.musicplayer.data.scanner

import android.content.ContentUris
import android.content.Context
import android.net.Uri
import android.os.Build
import android.provider.MediaStore
import com.example.musicplayer.model.Album
import com.example.musicplayer.model.Artist
import com.example.musicplayer.model.Folder
import com.example.musicplayer.model.Song
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

object MusicScanner {

    suspend fun scanAudioFiles(context: Context, includeSampleIfEmpty: Boolean = true): List<Song> =
        withContext(Dispatchers.IO) {
            val songList = mutableListOf<Song>()
            val collectionUri = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                MediaStore.Audio.Media.getContentUri(MediaStore.VOLUME_EXTERNAL)
            } else {
                MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
            }

            val projection = arrayOf(
                MediaStore.Audio.Media._ID,
                MediaStore.Audio.Media.TITLE,
                MediaStore.Audio.Media.ARTIST,
                MediaStore.Audio.Media.ALBUM,
                MediaStore.Audio.Media.ALBUM_ID,
                MediaStore.Audio.Media.DURATION,
                MediaStore.Audio.Media.DATA,
                MediaStore.Audio.Media.DATE_ADDED
            )

            val selection = "${MediaStore.Audio.Media.IS_MUSIC} != 0 AND ${MediaStore.Audio.Media.DURATION} >= 5000"
            val sortOrder = "${MediaStore.Audio.Media.TITLE} COLLATE NOCASE ASC"

            try {
                context.contentResolver.query(
                    collectionUri,
                    projection,
                    selection,
                    null,
                    sortOrder
                )?.use { cursor ->
                    val idCol = cursor.getColumnIndex(MediaStore.Audio.Media._ID)
                    val titleCol = cursor.getColumnIndex(MediaStore.Audio.Media.TITLE)
                    val artistCol = cursor.getColumnIndex(MediaStore.Audio.Media.ARTIST)
                    val albumCol = cursor.getColumnIndex(MediaStore.Audio.Media.ALBUM)
                    val albumIdCol = cursor.getColumnIndex(MediaStore.Audio.Media.ALBUM_ID)
                    val durationCol = cursor.getColumnIndex(MediaStore.Audio.Media.DURATION)
                    val dataCol = cursor.getColumnIndex(MediaStore.Audio.Media.DATA)
                    val dateAddedCol = cursor.getColumnIndex(MediaStore.Audio.Media.DATE_ADDED)

                    while (cursor.moveToNext()) {
                        val id = if (idCol >= 0) cursor.getLong(idCol) else 0L
                        val title = if (titleCol >= 0) cursor.getString(titleCol) ?: "Unknown Title" else "Unknown Title"
                        val artist = if (artistCol >= 0) cursor.getString(artistCol) ?: "Unknown Artist" else "Unknown Artist"
                        val album = if (albumCol >= 0) cursor.getString(albumCol) ?: "Unknown Album" else "Unknown Album"
                        val albumId = if (albumIdCol >= 0) cursor.getLong(albumIdCol) else 0L
                        val duration = if (durationCol >= 0) cursor.getLong(durationCol) else 0L
                        val path = if (dataCol >= 0) cursor.getString(dataCol) ?: "" else ""
                        val dateAdded = if (dateAddedCol >= 0) cursor.getLong(dateAddedCol) else 0L

                        val contentUri = ContentUris.withAppendedId(
                            MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,
                            id
                        ).toString()

                        val albumArtUri = if (albumId > 0) {
                            ContentUris.withAppendedId(
                                Uri.parse("content://media/external/audio/albumart"),
                                albumId
                            ).toString()
                        } else null

                        val folder = try {
                            if (path.isNotEmpty()) {
                                val parent = File(path).parentFile
                                parent?.name ?: "Music"
                            } else "Music"
                        } catch (e: Exception) {
                            "Music"
                        }

                        songList.add(
                            Song(
                                id = id,
                                title = title,
                                artist = if (artist == "<unknown>") "Unknown Artist" else artist,
                                album = if (album == "<unknown>") "Unknown Album" else album,
                                albumId = albumId,
                                duration = duration,
                                uri = contentUri,
                                albumArtUri = albumArtUri,
                                path = path,
                                folder = folder,
                                dateAdded = dateAdded
                            )
                        )
                    }
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }

            if (songList.isEmpty() && includeSampleIfEmpty) {
                try {
                    val samples = SampleMusicProvider.getOrCreateSampleTracks(context)
                    songList.addAll(samples)
                } catch (e: Exception) {
                    e.printStackTrace()
                }
            }

            songList
        }

    fun groupArtists(songs: List<Song>): List<Artist> {
        return songs.groupBy { it.artist }
            .map { (artistName, artistSongs) ->
                Artist(
                    id = artistSongs.first().id,
                    name = artistName,
                    songCount = artistSongs.size
                )
            }
            .sortedBy { it.name.lowercase() }
    }

    fun groupAlbums(songs: List<Song>): List<Album> {
        return songs.groupBy { it.albumId to it.album }
            .map { (key, albumSongs) ->
                val first = albumSongs.first()
                Album(
                    id = key.first,
                    title = key.second,
                    artist = first.artist,
                    albumArtUri = first.albumArtUri,
                    songCount = albumSongs.size
                )
            }
            .sortedBy { it.title.lowercase() }
    }

    fun groupFolders(songs: List<Song>): List<Folder> {
        return songs.groupBy { it.folder }
            .map { (folderName, folderSongs) ->
                val first = folderSongs.first()
                val parentPath = try {
                    if (first.path.isNotEmpty()) File(first.path).parent ?: folderName else folderName
                } catch (e: Exception) {
                    folderName
                }
                Folder(
                    name = folderName,
                    path = parentPath,
                    songCount = folderSongs.size
                )
            }
            .sortedBy { it.name.lowercase() }
    }
}
