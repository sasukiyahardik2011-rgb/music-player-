package com.example.musicplayer.ui

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.Crossfade
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.QueueMusic
import androidx.compose.material.icons.filled.Album
import androidx.compose.material.icons.filled.Equalizer
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.LibraryMusic
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CenterAlignedTopAppBar
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.ScrollableTabRow
import androidx.compose.material3.Tab
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import com.example.musicplayer.viewmodel.MusicViewModel

enum class MainNavTab(val title: String, val icon: ImageVector) {
    HOME("Home", Icons.Default.Home),
    LIBRARY("Library", Icons.Default.LibraryMusic),
    SEARCH("Search", Icons.Default.Search),
    SETTINGS("Settings", Icons.Default.Settings)
}

enum class LibrarySubTab(val title: String, val icon: ImageVector) {
    SONGS("Songs", Icons.Default.MusicNote),
    ARTISTS("Artists", Icons.Default.Person),
    ALBUMS("Albums", Icons.Default.Album),
    FOLDERS("Folders", Icons.Default.Folder),
    FAVORITES("Favorites", Icons.Default.Favorite),
    PLAYLISTS("Playlists", Icons.AutoMirrored.Filled.QueueMusic)
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MusicApp(
    viewModel: MusicViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    var currentNavTab by remember { mutableStateOf(MainNavTab.HOME) }
    var currentLibrarySubTab by remember { mutableStateOf(LibrarySubTab.SONGS) }

    // Detail screens state
    val selectedArtist by viewModel.selectedArtist.collectAsState()
    val selectedAlbum by viewModel.selectedAlbum.collectAsState()
    val selectedFolder by viewModel.selectedFolder.collectAsState()
    val selectedPlaylist by viewModel.selectedPlaylist.collectAsState()

    // Modals state
    val isFullPlayerVisible by viewModel.isFullPlayerVisible.collectAsState()
    val isQueueVisible by viewModel.isQueueSheetVisible.collectAsState()
    val isEqualizerVisible by viewModel.isEqualizerSheetVisible.collectAsState()
    val isSleepTimerVisible by viewModel.isSleepTimerDialogVisible.collectAsState()
    val isAddToPlaylistVisible by viewModel.isAddToPlaylistDialogVisible.collectAsState()
    val isCreatePlaylistVisible by viewModel.isCreatePlaylistDialogVisible.collectAsState()
    val songToAddToPlaylist by viewModel.songToAddToPlaylist.collectAsState()
    val sleepTimer by viewModel.sleepTimer.collectAsState()

    // Permission state
    var hasAudioPermission by remember {
        mutableStateOf(checkAudioPermission(context))
    }

    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestMultiplePermissions()
    ) { permissions ->
        val audioGranted = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            permissions[Manifest.permission.READ_MEDIA_AUDIO] == true
        } else {
            permissions[Manifest.permission.READ_EXTERNAL_STORAGE] == true
        }
        hasAudioPermission = audioGranted
        if (audioGranted) {
            viewModel.refreshLibrary()
        }
    }

    LaunchedEffect(Unit) {
        if (!hasAudioPermission) {
            val neededPermissions = mutableListOf<String>()
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                neededPermissions.add(Manifest.permission.READ_MEDIA_AUDIO)
                neededPermissions.add(Manifest.permission.POST_NOTIFICATIONS)
            } else {
                neededPermissions.add(Manifest.permission.READ_EXTERNAL_STORAGE)
            }
            permissionLauncher.launch(neededPermissions.toTypedArray())
        }
    }

    Scaffold(
        modifier = modifier.fillMaxSize(),
        contentWindowInsets = WindowInsets(0, 0, 0, 0),
        topBar = {
            if (selectedArtist == null && selectedAlbum == null && selectedFolder == null && selectedPlaylist == null) {
                CenterAlignedTopAppBar(
                    title = {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.MusicNote,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(24.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "Music Player",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    },
                    actions = {
                        // Equalizer shortcut
                        IconButton(
                            onClick = { viewModel.isEqualizerSheetVisible.value = true },
                            modifier = Modifier.testTag("top_bar_equalizer_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Equalizer,
                                contentDescription = "Equalizer",
                                tint = MaterialTheme.colorScheme.onSurface
                            )
                        }

                        // Sleep timer shortcut
                        IconButton(
                            onClick = { viewModel.isSleepTimerDialogVisible.value = true },
                            modifier = Modifier.testTag("top_bar_sleep_timer_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Timer,
                                contentDescription = "Sleep timer",
                                tint = if (sleepTimer.isActive) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface
                            )
                        }
                    },
                    colors = TopAppBarDefaults.centerAlignedTopAppBarColors(
                        containerColor = MaterialTheme.colorScheme.surface
                    )
                )
            }
        },
        bottomBar = {
            Column(modifier = Modifier.fillMaxWidth()) {
                MiniPlayer(
                    viewModel = viewModel,
                    modifier = Modifier.fillMaxWidth()
                )

                NavigationBar(
                    containerColor = MaterialTheme.colorScheme.surface,
                    tonalElevation = 8.dp,
                    modifier = Modifier.testTag("main_navigation_bar")
                ) {
                    MainNavTab.entries.forEach { tab ->
                        NavigationBarItem(
                            selected = currentNavTab == tab && selectedArtist == null && selectedAlbum == null && selectedFolder == null && selectedPlaylist == null,
                            onClick = {
                                viewModel.selectArtist(null)
                                viewModel.selectAlbum(null)
                                viewModel.selectFolder(null)
                                viewModel.selectPlaylist(null)
                                currentNavTab = tab
                            },
                            icon = { Icon(tab.icon, contentDescription = tab.title) },
                            label = { Text(tab.title) },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = MaterialTheme.colorScheme.primary,
                                selectedTextColor = MaterialTheme.colorScheme.primary,
                                indicatorColor = MaterialTheme.colorScheme.primaryContainer
                            ),
                            modifier = Modifier.testTag("nav_tab_${tab.name.lowercase()}")
                        )
                    }
                }
            }
        }
    ) { paddingValues ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
        ) {
            Column(modifier = Modifier.fillMaxSize()) {
                // Permission Warning Banner if denied
                if (!hasAudioPermission) {
                    PermissionBanner(
                        onRequestPermission = {
                            val perms = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                                arrayOf(Manifest.permission.READ_MEDIA_AUDIO, Manifest.permission.POST_NOTIFICATIONS)
                            } else {
                                arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE)
                            }
                            permissionLauncher.launch(perms)
                        },
                        onOpenSettings = {
                            val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
                                data = Uri.fromParts("package", context.packageName, null)
                            }
                            context.startActivity(intent)
                        }
                    )
                }

                // Detail Screens take precedence when active
                when {
                    selectedArtist != null -> {
                        ArtistDetailScreen(
                            artist = selectedArtist!!,
                            viewModel = viewModel,
                            onBack = { viewModel.selectArtist(null) }
                        )
                    }
                    selectedAlbum != null -> {
                        AlbumDetailScreen(
                            album = selectedAlbum!!,
                            viewModel = viewModel,
                            onBack = { viewModel.selectAlbum(null) }
                        )
                    }
                    selectedFolder != null -> {
                        FolderDetailScreen(
                            folder = selectedFolder!!,
                            viewModel = viewModel,
                            onBack = { viewModel.selectFolder(null) }
                        )
                    }
                    selectedPlaylist != null -> {
                        PlaylistDetailScreen(
                            playlist = selectedPlaylist!!,
                            viewModel = viewModel,
                            onBack = { viewModel.selectPlaylist(null) }
                        )
                    }
                    else -> {
                        // Main Navigation content
                        Crossfade(targetState = currentNavTab, label = "MainTabCrossfade") { tab ->
                            when (tab) {
                                MainNavTab.HOME -> {
                                    HomeScreen(viewModel = viewModel)
                                }
                                MainNavTab.LIBRARY -> {
                                    Column(modifier = Modifier.fillMaxSize()) {
                                        ScrollableTabRow(
                                            selectedTabIndex = currentLibrarySubTab.ordinal,
                                            edgePadding = 16.dp,
                                            containerColor = MaterialTheme.colorScheme.surface,
                                            contentColor = MaterialTheme.colorScheme.primary,
                                            modifier = Modifier.fillMaxWidth()
                                        ) {
                                            LibrarySubTab.entries.forEach { subTab ->
                                                Tab(
                                                    selected = currentLibrarySubTab == subTab,
                                                    onClick = { currentLibrarySubTab = subTab },
                                                    text = { Text(subTab.title, fontWeight = FontWeight.SemiBold) },
                                                    icon = { Icon(subTab.icon, contentDescription = null, modifier = Modifier.size(18.dp)) }
                                                )
                                            }
                                        }

                                        Crossfade(targetState = currentLibrarySubTab, label = "LibrarySubTabCrossfade") { subTab ->
                                            when (subTab) {
                                                LibrarySubTab.SONGS -> SongsScreen(viewModel = viewModel)
                                                LibrarySubTab.ARTISTS -> ArtistsScreen(viewModel = viewModel)
                                                LibrarySubTab.ALBUMS -> AlbumsScreen(viewModel = viewModel)
                                                LibrarySubTab.FOLDERS -> FoldersScreen(viewModel = viewModel)
                                                LibrarySubTab.FAVORITES -> FavoritesScreen(viewModel = viewModel)
                                                LibrarySubTab.PLAYLISTS -> PlaylistsScreen(viewModel = viewModel)
                                            }
                                        }
                                    }
                                }
                                MainNavTab.SEARCH -> {
                                    SearchScreen(viewModel = viewModel)
                                }
                                MainNavTab.SETTINGS -> {
                                    SettingsScreen(viewModel = viewModel)
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // Modal Sheets & Dialogs
    if (isFullPlayerVisible) {
        FullPlayerModal(
            viewModel = viewModel,
            onDismiss = { viewModel.isFullPlayerVisible.value = false }
        )
    }

    if (isQueueVisible) {
        QueueBottomSheet(
            viewModel = viewModel,
            onDismiss = { viewModel.isQueueSheetVisible.value = false }
        )
    }

    if (isEqualizerVisible) {
        EqualizerBottomSheet(
            viewModel = viewModel,
            onDismiss = { viewModel.isEqualizerSheetVisible.value = false }
        )
    }

    if (isSleepTimerVisible) {
        SleepTimerDialog(
            viewModel = viewModel,
            onDismiss = { viewModel.isSleepTimerDialogVisible.value = false }
        )
    }

    if (isAddToPlaylistVisible && songToAddToPlaylist != null) {
        AddToPlaylistDialog(
            viewModel = viewModel,
            song = songToAddToPlaylist!!,
            onDismiss = {
                viewModel.isAddToPlaylistDialogVisible.value = false
                viewModel.songToAddToPlaylist.value = null
            }
        )
    }

    if (isCreatePlaylistVisible) {
        CreatePlaylistDialog(
            viewModel = viewModel,
            onDismiss = { viewModel.isCreatePlaylistDialogVisible.value = false }
        )
    }
}

@Composable
fun PermissionBanner(
    onRequestPermission: () -> Unit,
    onOpenSettings: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer),
        shape = RoundedCornerShape(16.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Default.Warning,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.error
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "Audio Permission Needed",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onErrorContainer
                )
            }
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = "Music Player needs access to audio files on your device to discover and play songs in your music library.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onErrorContainer
            )
            Spacer(modifier = Modifier.height(12.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(
                    onClick = onRequestPermission,
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
                ) {
                    Text("Grant Permission")
                }
                OutlinedButton(onClick = onOpenSettings) {
                    Text("Settings")
                }
            }
        }
    }
}

fun checkAudioPermission(context: android.content.Context): Boolean {
    return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
        ContextCompat.checkSelfPermission(
            context,
            Manifest.permission.READ_MEDIA_AUDIO
        ) == PackageManager.PERMISSION_GRANTED
    } else {
        ContextCompat.checkSelfPermission(
            context,
            Manifest.permission.READ_EXTERNAL_STORAGE
        ) == PackageManager.PERMISSION_GRANTED
    }
}
