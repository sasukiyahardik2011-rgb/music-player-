package com.example.musicplayer.viewmodel

import android.app.Application
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.ServiceConnection
import android.os.IBinder
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.musicplayer.data.repository.MusicRepository
import com.example.musicplayer.model.Album
import com.example.musicplayer.model.Artist
import com.example.musicplayer.model.EqualizerState
import com.example.musicplayer.model.Folder
import com.example.musicplayer.model.PlaybackRepeatMode
import com.example.musicplayer.model.Playlist
import com.example.musicplayer.model.SleepTimerStatus
import com.example.musicplayer.model.Song
import com.example.musicplayer.service.MusicService
import com.example.ui.theme.ThemeMode
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

@OptIn(ExperimentalCoroutinesApi::class)
class MusicViewModel(application: Application) : AndroidViewModel(application) {

    private val repository = MusicRepository(application)

    // Service binding
    private var musicService: MusicService? = null
    private val _isServiceBound = MutableStateFlow(false)
    val isServiceBound: StateFlow<Boolean> = _isServiceBound.asStateFlow()

    private val serviceConnection = object : ServiceConnection {
        override fun onServiceConnected(name: ComponentName?, service: IBinder?) {
            val binder = service as? MusicService.MusicBinder
            musicService = binder?.getService()
            _isServiceBound.value = true
            observeService()
        }

        override fun onServiceDisconnected(name: ComponentName?) {
            musicService = null
            _isServiceBound.value = false
        }
    }

    // Playback state forwarded from service
    private val _currentSong = MutableStateFlow<Song?>(null)
    val currentSong: StateFlow<Song?> = _currentSong.asStateFlow()

    private val _isPlaying = MutableStateFlow(false)
    val isPlaying: StateFlow<Boolean> = _isPlaying.asStateFlow()

    private val _currentPosition = MutableStateFlow(0L)
    val currentPosition: StateFlow<Long> = _currentPosition.asStateFlow()

    private val _duration = MutableStateFlow(0L)
    val duration: StateFlow<Long> = _duration.asStateFlow()

    private val _queue = MutableStateFlow<List<Song>>(emptyList())
    val queue: StateFlow<List<Song>> = _queue.asStateFlow()

    private val _repeatMode = MutableStateFlow(PlaybackRepeatMode.OFF)
    val repeatMode: StateFlow<PlaybackRepeatMode> = _repeatMode.asStateFlow()

    private val _isShuffle = MutableStateFlow(false)
    val isShuffle: StateFlow<Boolean> = _isShuffle.asStateFlow()

    private val _playbackSpeed = MutableStateFlow(1.0f)
    val playbackSpeed: StateFlow<Float> = _playbackSpeed.asStateFlow()

    private val _sleepTimer = MutableStateFlow(SleepTimerStatus())
    val sleepTimer: StateFlow<SleepTimerStatus> = _sleepTimer.asStateFlow()

    private val _equalizerState = MutableStateFlow(EqualizerState())
    val equalizerState: StateFlow<EqualizerState> = _equalizerState.asStateFlow()

    // Library data from Repository
    val allSongs: StateFlow<List<Song>> = repository.allSongs
    val artists: StateFlow<List<Artist>> = repository.artists
    val albums: StateFlow<List<Album>> = repository.albums
    val folders: StateFlow<List<Folder>> = repository.folders
    val isScanning: StateFlow<Boolean> = repository.isScanning

    val favorites: StateFlow<List<Song>> = repository.favorites.stateIn(
        viewModelScope,
        SharingStarted.WhileSubscribed(5000),
        emptyList()
    )

    val recentlyPlayed: StateFlow<List<Song>> = repository.recentlyPlayed.stateIn(
        viewModelScope,
        SharingStarted.WhileSubscribed(5000),
        emptyList()
    )

    val playlists: StateFlow<List<Playlist>> = repository.playlists.stateIn(
        viewModelScope,
        SharingStarted.WhileSubscribed(5000),
        emptyList()
    )

    val themeMode: StateFlow<ThemeMode> = repository.themeMode.stateIn(
        viewModelScope,
        SharingStarted.WhileSubscribed(5000),
        ThemeMode.SYSTEM
    )

    // Current song favorite status
    val isCurrentSongFavorite: StateFlow<Boolean> = _currentSong.flatMapLatest { song ->
        if (song != null) repository.isFavorite(song.id) else flowOf(false)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), false)

    // Search state
    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    val searchResults: StateFlow<SearchResults> = combine(_searchQuery, allSongs) { query, songs ->
        if (query.isBlank()) {
            SearchResults(emptyList(), emptyList(), emptyList())
        } else {
            val q = query.trim().lowercase()
            val filteredSongs = songs.filter {
                it.title.lowercase().contains(q) || it.artist.lowercase().contains(q) || it.album.lowercase().contains(q)
            }
            val filteredArtists = repository.artists.value.filter { it.name.lowercase().contains(q) }
            val filteredAlbums = repository.albums.value.filter { it.title.lowercase().contains(q) || it.artist.lowercase().contains(q) }
            SearchResults(filteredSongs, filteredArtists, filteredAlbums)
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), SearchResults())

    // UI Navigation & Detail selections
    private val _selectedArtist = MutableStateFlow<Artist?>(null)
    val selectedArtist: StateFlow<Artist?> = _selectedArtist.asStateFlow()

    private val _selectedAlbum = MutableStateFlow<Album?>(null)
    val selectedAlbum: StateFlow<Album?> = _selectedAlbum.asStateFlow()

    private val _selectedFolder = MutableStateFlow<Folder?>(null)
    val selectedFolder: StateFlow<Folder?> = _selectedFolder.asStateFlow()

    private val _selectedPlaylist = MutableStateFlow<Playlist?>(null)
    val selectedPlaylist: StateFlow<Playlist?> = _selectedPlaylist.asStateFlow()

    // Dialog & Screen Visibility
    val isFullPlayerVisible = MutableStateFlow(false)
    val isSleepTimerDialogVisible = MutableStateFlow(false)
    val isEqualizerSheetVisible = MutableStateFlow(false)
    val isQueueSheetVisible = MutableStateFlow(false)
    val isAddToPlaylistDialogVisible = MutableStateFlow(false)
    val isCreatePlaylistDialogVisible = MutableStateFlow(false)
    val songToAddToPlaylist = MutableStateFlow<Song?>(null)

    init {
        bindService()
        refreshLibrary()
    }

    private fun bindService() {
        val intent = Intent(getApplication(), MusicService::class.java)
        try {
            getApplication<Application>().bindService(intent, serviceConnection, Context.BIND_AUTO_CREATE)
        } catch (e: Exception) {
            android.util.Log.e("MusicViewModel", "Failed to bind MusicService: ${e.message}", e)
        }
    }

    private fun observeService() {
        val service = musicService ?: return
        viewModelScope.launch {
            service.currentSong.collect { song ->
                _currentSong.value = song
                if (song != null) {
                    repository.recordPlayed(song)
                }
            }
        }
        viewModelScope.launch { service.isPlaying.collect { _isPlaying.value = it } }
        viewModelScope.launch { service.currentPosition.collect { _currentPosition.value = it } }
        viewModelScope.launch { service.duration.collect { _duration.value = it } }
        viewModelScope.launch { service.queue.collect { _queue.value = it } }
        viewModelScope.launch { service.repeatMode.collect { _repeatMode.value = it } }
        viewModelScope.launch { service.isShuffle.collect { _isShuffle.value = it } }
        viewModelScope.launch { service.playbackSpeed.collect { _playbackSpeed.value = it } }
        viewModelScope.launch { service.sleepTimer.collect { _sleepTimer.value = it } }
        viewModelScope.launch {
            service.audioEffectsManager.equalizerState.collect { _equalizerState.value = it }
        }
    }

    // Playback Controls
    fun playSong(song: Song, queueList: List<Song>? = null) {
        val currentList = queueList ?: allSongs.value
        val index = currentList.indexOfFirst { it.id == song.id }.let { if (it >= 0) it else 0 }
        musicService?.playSongs(currentList, index)
    }

    fun playQueue(songs: List<Song>, startIndex: Int = 0) {
        if (songs.isNotEmpty()) {
            musicService?.playSongs(songs, startIndex)
        }
    }

    fun togglePlayPause() {
        musicService?.playPause()
    }

    fun seekTo(positionMs: Long) {
        musicService?.seekTo(positionMs)
    }

    fun skipToNext() {
        musicService?.skipToNext()
    }

    fun skipToPrevious() {
        musicService?.skipToPrevious()
    }

    fun skipToQueueIndex(index: Int) {
        musicService?.skipToQueueIndex(index)
    }

    fun removeFromQueue(index: Int) {
        musicService?.removeFromQueue(index)
    }

    fun toggleShuffle() {
        musicService?.toggleShuffle()
    }

    fun toggleRepeatMode() {
        musicService?.toggleRepeatMode()
    }

    fun setPlaybackSpeed(speed: Float) {
        musicService?.setPlaybackSpeed(speed)
    }

    fun startSleepTimer(minutes: Int) {
        musicService?.startSleepTimer(minutes)
        isSleepTimerDialogVisible.value = false
    }

    fun cancelSleepTimer() {
        musicService?.cancelSleepTimer()
    }

    // Equalizer Controls
    fun setEqualizerEnabled(enabled: Boolean) {
        musicService?.audioEffectsManager?.setEnabled(enabled)
    }

    fun setEqualizerPreset(presetIndex: Int) {
        musicService?.audioEffectsManager?.usePreset(presetIndex)
    }

    fun setEqualizerBandLevel(band: Short, level: Short) {
        musicService?.audioEffectsManager?.setBandLevel(band, level)
    }

    fun setBassBoost(strength: Short) {
        musicService?.audioEffectsManager?.setBassBoost(strength)
    }

    fun setVirtualizer(strength: Short) {
        musicService?.audioEffectsManager?.setVirtualizer(strength)
    }

    // Favorites
    fun toggleFavorite(song: Song) {
        viewModelScope.launch {
            val isFav = favorites.value.any { it.id == song.id }
            repository.toggleFavorite(song, isFav)
        }
    }

    // Playlists
    fun createPlaylist(name: String) {
        viewModelScope.launch {
            repository.createPlaylist(name)
            isCreatePlaylistDialogVisible.value = false
        }
    }

    fun renamePlaylist(id: Long, newName: String) {
        viewModelScope.launch {
            repository.renamePlaylist(id, newName)
        }
    }

    fun deletePlaylist(id: Long) {
        viewModelScope.launch {
            repository.deletePlaylist(id)
            if (_selectedPlaylist.value?.id == id) {
                _selectedPlaylist.value = null
            }
        }
    }

    fun addSongToPlaylist(playlistId: Long, song: Song) {
        viewModelScope.launch {
            repository.addSongToPlaylist(playlistId, song)
            isAddToPlaylistDialogVisible.value = false
            songToAddToPlaylist.value = null
        }
    }

    fun removeSongFromPlaylist(playlistId: Long, songId: Long) {
        viewModelScope.launch {
            repository.removeSongFromPlaylist(playlistId, songId)
        }
    }

    fun getSongsForPlaylist(playlistId: Long): Flow<List<Song>> = repository.getSongsForPlaylist(playlistId)

    // Library operations
    fun refreshLibrary() {
        viewModelScope.launch {
            repository.refreshLibrary()
        }
    }

    fun clearRecentlyPlayed() {
        viewModelScope.launch {
            repository.clearRecentlyPlayed()
        }
    }

    fun setThemeMode(mode: ThemeMode) {
        viewModelScope.launch {
            repository.setThemeMode(mode)
        }
    }

    fun setSearchQuery(query: String) {
        _searchQuery.value = query
    }

    // Detail Screen Navigation
    fun selectArtist(artist: Artist?) {
        _selectedArtist.value = artist
    }

    fun selectAlbum(album: Album?) {
        _selectedAlbum.value = album
    }

    fun selectFolder(folder: Folder?) {
        _selectedFolder.value = folder
    }

    fun selectPlaylist(playlist: Playlist?) {
        _selectedPlaylist.value = playlist
    }

    override fun onCleared() {
        try {
            getApplication<Application>().unbindService(serviceConnection)
        } catch (e: Exception) {
            e.printStackTrace()
        }
        super.onCleared()
    }
}

data class SearchResults(
    val songs: List<Song> = emptyList(),
    val artists: List<Artist> = emptyList(),
    val albums: List<Album> = emptyList()
)
