package com.example.musicplayer.model

data class Song(
    val id: Long,
    val title: String,
    val artist: String,
    val album: String,
    val albumId: Long = 0L,
    val duration: Long, // in milliseconds
    val uri: String,
    val albumArtUri: String? = null,
    val path: String = "",
    val folder: String = "Music",
    val dateAdded: Long = 0L
) {
    val formattedDuration: String
        get() {
            val totalSeconds = (duration / 1000).coerceAtLeast(0)
            val minutes = totalSeconds / 60
            val seconds = totalSeconds % 60
            return "%d:%02d".format(minutes, seconds)
        }
}

data class Album(
    val id: Long,
    val title: String,
    val artist: String,
    val albumArtUri: String?,
    val songCount: Int
)

data class Artist(
    val id: Long,
    val name: String,
    val songCount: Int
)

data class Folder(
    val name: String,
    val path: String,
    val songCount: Int
)

data class Playlist(
    val id: Long,
    val name: String,
    val createdAt: Long,
    val songCount: Int = 0
)

enum class PlaybackRepeatMode {
    OFF,
    ALL,
    ONE
}

data class SleepTimerStatus(
    val isActive: Boolean = false,
    val remainingSeconds: Long = 0L,
    val initialMinutes: Int = 0
) {
    val formattedRemaining: String
        get() {
            val m = remainingSeconds / 60
            val s = remainingSeconds % 60
            return "%02d:%02d".format(m, s)
        }
}

data class EqualizerState(
    val isSupported: Boolean = true,
    val isEnabled: Boolean = false,
    val currentPreset: Int = 0,
    val presets: List<String> = emptyList(),
    val bandLevels: Map<Short, Short> = emptyMap(), // band index to level in mB
    val minBandLevel: Short = -1500,
    val maxBandLevel: Short = 1500,
    val bandCenterFreqs: Map<Short, Int> = emptyMap(), // band index to center freq in mHz
    val bassBoostStrength: Short = 0, // 0 - 1000
    val virtualizerStrength: Short = 0 // 0 - 1000
)
