package com.example.musicplayer.data.scanner

import android.content.Context
import android.net.Uri
import com.example.musicplayer.model.Song
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.io.RandomAccessFile
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.sin

object SampleMusicProvider {

    suspend fun getOrCreateSampleTracks(context: Context): List<Song> = withContext(Dispatchers.IO) {
        val cacheDir = File(context.filesDir, "sample_music")
        if (!cacheDir.exists()) {
            cacheDir.mkdirs()
        }

        val tracks = listOf(
            SampleTrackDef(
                title = "Midnight Horizon",
                artist = "Aura Soundscape",
                album = "Cosmic Dreams",
                durationSeconds = 64,
                baseFreq = 220.0, // A3
                scale = doubleArrayOf(220.0, 246.94, 277.18, 329.63, 369.99, 440.0)
            ),
            SampleTrackDef(
                title = "Neon Sunset",
                artist = "Synthwave Velocity",
                album = "Electric Twilight",
                durationSeconds = 58,
                baseFreq = 261.63, // C4
                scale = doubleArrayOf(261.63, 293.66, 329.63, 392.00, 440.00, 523.25)
            ),
            SampleTrackDef(
                title = "Acoustic Morning",
                artist = "Gentle Breeze",
                album = "Acoustic Sessions",
                durationSeconds = 72,
                baseFreq = 196.0, // G3
                scale = doubleArrayOf(196.0, 220.0, 246.94, 293.66, 329.63, 392.0)
            ),
            SampleTrackDef(
                title = "Chill Hop Vibes",
                artist = "Lo-Fi Beats Collective",
                album = "Study & Relax",
                durationSeconds = 60,
                baseFreq = 174.61, // F3
                scale = doubleArrayOf(174.61, 196.00, 220.00, 261.63, 293.66, 349.23)
            )
        )

        tracks.mapIndexed { index, def ->
            val file = File(cacheDir, "sample_track_${index + 1}.wav")
            if (!file.exists() || file.length() < 1000) {
                generateWavFile(file, def)
            }
            Song(
                id = -(index + 100L), // negative IDs for sample tracks
                title = def.title,
                artist = def.artist,
                album = def.album,
                albumId = -(index + 10L),
                duration = def.durationSeconds * 1000L,
                uri = Uri.fromFile(file).toString(),
                albumArtUri = null,
                path = file.absolutePath,
                folder = "Demo Library",
                dateAdded = System.currentTimeMillis()
            )
        }
    }

    private data class SampleTrackDef(
        val title: String,
        val artist: String,
        val album: String,
        val durationSeconds: Int,
        val baseFreq: Double,
        val scale: DoubleArray
    )

    private fun generateWavFile(file: File, def: SampleTrackDef) {
        val sampleRate = 22050
        val totalSamples = sampleRate * def.durationSeconds
        val numChannels = 1
        val bitsPerSample = 16

        FileOutputStream(file).use { out ->
            // Write placeholder WAV header
            val header = ByteArray(44)
            out.write(header)

            val buffer = ShortArray(2048)
            var sampleIndex = 0

            // Melody timing
            val beatLength = sampleRate / 2 // 0.5 sec per note
            val noteCount = def.scale.size

            while (sampleIndex < totalSamples) {
                val chunkSize = minOf(buffer.size, totalSamples - sampleIndex)
                for (i in 0 until chunkSize) {
                    val currentGlobal = sampleIndex + i
                    val noteIndex = (currentGlobal / beatLength) % noteCount
                    val noteFreq = def.scale[noteIndex]
                    val t = currentGlobal.toDouble() / sampleRate

                    // Add fundamental tone + gentle harmonic + envelope
                    val envelope = 0.5 + 0.5 * sin(2.0 * Math.PI * (currentGlobal % beatLength) / beatLength)
                    val sampleValue = (
                        sin(2.0 * Math.PI * noteFreq * t) * 0.7 +
                        sin(2.0 * Math.PI * (noteFreq * 2.0) * t) * 0.2 +
                        sin(2.0 * Math.PI * (def.baseFreq / 2.0) * t) * 0.3
                    ) * envelope * 0.6

                    buffer[i] = (sampleValue * 32767.0).toInt().coerceIn(-32768, 32767).toShort()
                }

                val byteBuf = ByteBuffer.allocate(chunkSize * 2).order(ByteOrder.LITTLE_ENDIAN)
                for (i in 0 until chunkSize) {
                    byteBuf.putShort(buffer[i])
                }
                out.write(byteBuf.array(), 0, chunkSize * 2)
                sampleIndex += chunkSize
            }
        }

        // Write accurate RIFF WAV header
        val audioDataSize = totalSamples * numChannels * (bitsPerSample / 8)
        val totalDataLen = audioDataSize + 36

        RandomAccessFile(file, "rw").use { raf ->
            val header = ByteBuffer.allocate(44).order(ByteOrder.LITTLE_ENDIAN)
            header.put("RIFF".toByteArray())
            header.putInt(totalDataLen)
            header.put("WAVE".toByteArray())
            header.put("fmt ".toByteArray())
            header.putInt(16) // Subchunk1Size
            header.putShort(1) // AudioFormat PCM
            header.putShort(numChannels.toShort())
            header.putInt(sampleRate)
            header.putInt(sampleRate * numChannels * (bitsPerSample / 8)) // ByteRate
            header.putShort((numChannels * (bitsPerSample / 8)).toShort()) // BlockAlign
            header.putShort(bitsPerSample.toShort())
            header.put("data".toByteArray())
            header.putInt(audioDataSize)

            raf.seek(0)
            raf.write(header.array())
        }
    }
}
