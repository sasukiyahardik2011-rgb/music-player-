package com.example.musicplayer.data.repository

import android.content.Context
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.example.musicplayer.data.db.FavoriteSongEntity
import com.example.musicplayer.data.db.MusicDatabase
import com.example.musicplayer.data.db.PlaylistEntity
import com.example.musicplayer.data.db.PlaylistSongCrossRef
import com.example.musicplayer.data.db.RecentlyPlayedEntity
import com.example.musicplayer.data.scanner.MusicScanner
import com.example.musicplayer.model.Album
import com.example.musicplayer.model.Artist
import com.example.musicplayer.model.Folder
import com.example.musicplayer.model.Playlist
import com.example.musicplayer.model.Song
import com.example.ui.theme.ThemeMode
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.map

private val Context.dataStore by preferencesDataStore(name = "music_player_settings")

class MusicRepository(private val context: Context) {

    private val db = MusicDatabase.getDatabase(context)
    private val favoriteDao = db.favoriteDao()
    private val recentDao = db.recentlyPlayedDao()
    private val playlistDao = db.playlistDao()

    private val THEME_KEY = stringPreferencesKey("app_theme_mode")

    // In-memory cached scanned library
    private val _allSongs = MutableStateFlow<List<Song>>(emptyList())
    val allSongs: StateFlow<List<Song>> = _allSongs.asStateFlow()

    private val _artists = MutableStateFlow<List<Artist>>(emptyList())
    val artists: StateFlow<List<Artist>> = _artists.asStateFlow()

    private val _albums = MutableStateFlow<List<Album>>(emptyList())
    val albums: StateFlow<List<Album>> = _albums.asStateFlow()

    private val _folders = MutableStateFlow<List<Folder>>(emptyList())
    val folders: StateFlow<List<Folder>> = _folders.asStateFlow()

    private val _isScanning = MutableStateFlow(false)
    val isScanning: StateFlow<Boolean> = _isScanning.asStateFlow()

    // Favorites
    val favorites: Flow<List<Song>> = favoriteDao.getAllFavorites().map { list ->
        list.map { it.toSong() }
    }

    fun isFavorite(songId: Long): Flow<Boolean> = favoriteDao.isFavorite(songId)

    suspend fun toggleFavorite(song: Song, currentlyFavorite: Boolean) {
        if (currentlyFavorite) {
            favoriteDao.deleteFavorite(song.id)
        } else {
            favoriteDao.insertFavorite(
                FavoriteSongEntity(
                    songId = song.id,
                    title = song.title,
                    artist = song.artist,
                    album = song.album,
                    albumId = song.albumId,
                    duration = song.duration,
                    uri = song.uri,
                    albumArtUri = song.albumArtUri,
                    path = song.path,
                    folder = song.folder
                )
            )
        }
    }

    // Recently Played
    val recentlyPlayed: Flow<List<Song>> = recentDao.getRecentlyPlayed(50).map { list ->
        list.map { it.toSong() }
    }

    suspend fun recordPlayed(song: Song) {
        recentDao.recordPlayed(
            RecentlyPlayedEntity(
                songId = song.id,
                title = song.title,
                artist = song.artist,
                album = song.album,
                albumId = song.albumId,
                duration = song.duration,
                uri = song.uri,
                albumArtUri = song.albumArtUri,
                path = song.path,
                folder = song.folder
            )
        )
    }

    suspend fun clearRecentlyPlayed() {
        recentDao.clearAll()
    }

    // Playlists
    val playlists: Flow<List<Playlist>> = playlistDao.getAllPlaylists().map { list ->
        list.map { entity ->
            Playlist(
                id = entity.playlistId,
                name = entity.name,
                createdAt = entity.createdAt
            )
        }
    }

    suspend fun createPlaylist(name: String): Long {
        return playlistDao.insertPlaylist(
            PlaylistEntity(
                name = name.trim().ifEmpty { "New Playlist" }
            )
        )
    }

    suspend fun renamePlaylist(playlistId: Long, newName: String) {
        val existing = playlistDao.getPlaylistById(playlistId) ?: return
        playlistDao.updatePlaylist(existing.copy(name = newName.trim().ifEmpty { existing.name }))
    }

    suspend fun deletePlaylist(playlistId: Long) {
        playlistDao.deletePlaylistAndSongs(playlistId)
    }

    fun getSongsForPlaylist(playlistId: Long): Flow<List<Song>> {
        return playlistDao.getSongsForPlaylist(playlistId).map { list ->
            list.map { it.toSong() }
        }
    }

    suspend fun addSongToPlaylist(playlistId: Long, song: Song) {
        playlistDao.addSongToPlaylist(
            PlaylistSongCrossRef(
                playlistId = playlistId,
                songId = song.id,
                title = song.title,
                artist = song.artist,
                album = song.album,
                albumId = song.albumId,
                duration = song.duration,
                uri = song.uri,
                albumArtUri = song.albumArtUri,
                path = song.path,
                folder = song.folder
            )
        )
    }

    suspend fun removeSongFromPlaylist(playlistId: Long, songId: Long) {
        playlistDao.removeSongFromPlaylist(playlistId, songId)
    }

    // Theme Mode
    val themeMode: Flow<ThemeMode> = context.dataStore.data.map { prefs ->
        val name = prefs[THEME_KEY] ?: ThemeMode.SYSTEM.name
        try {
            ThemeMode.valueOf(name)
        } catch (e: Exception) {
            ThemeMode.SYSTEM
        }
    }

    suspend fun setThemeMode(mode: ThemeMode) {
        context.dataStore.edit { prefs ->
            prefs[THEME_KEY] = mode.name
        }
    }

    // Scan Library
    suspend fun refreshLibrary() {
        _isScanning.value = true
        try {
            val scanned = MusicScanner.scanAudioFiles(context)
            _allSongs.value = scanned
            _artists.value = MusicScanner.groupArtists(scanned)
            _albums.value = MusicScanner.groupAlbums(scanned)
            _folders.value = MusicScanner.groupFolders(scanned)
        } finally {
            _isScanning.value = false
        }
    }
}
