package com.example

import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.onRoot
import com.example.musicplayer.model.Song
import com.example.musicplayer.ui.SongItemRow
import com.example.ui.theme.MusicPlayerTheme
import com.example.ui.theme.ThemeMode
import com.github.takahirom.roborazzi.RobolectricDeviceQualifiers
import com.github.takahirom.roborazzi.captureRoboImage
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import org.robolectric.annotation.GraphicsMode

@RunWith(RobolectricTestRunner::class)
@GraphicsMode(GraphicsMode.Mode.NATIVE)
@Config(qualifiers = RobolectricDeviceQualifiers.Pixel8, sdk = [36])
class GreetingScreenshotTest {

  @get:Rule val composeTestRule = createComposeRule()

  @Test
  fun music_player_row_screenshot() {
    val sampleSong = Song(
        id = 1L,
        title = "Moonlight Serenade",
        artist = "Acoustic Harmony",
        album = "Night Reverie",
        duration = 215000L,
        uri = "content://media/external/audio/media/1",
        folder = "Music"
    )

    composeTestRule.setContent {
      MusicPlayerTheme(themeMode = ThemeMode.DARK) {
        SongItemRow(
            song = sampleSong,
            isPlayingThis = true,
            onSongClick = {},
            onFavoriteClick = {},
            onAddToPlaylistClick = {},
            isFavorite = true
        )
      }
    }

    composeTestRule.onRoot().captureRoboImage(filePath = "src/test/screenshots/music_player_row.png")
  }
}
